#1 Now update the game to incude the following features:

#2 The game be a multi-user platform. 
Users must register and login to play. 
User scores must be stored on a leaderboard displayed on the landing page. 
The system should have 3 roles, anonymous, player and admin. 
Admins can create new puzzles and make new levels everyday to challenge players

#3 please refrain from using multiple langauges and databases
keep it as one python file for simplicity.

#4 check game logic and level creation ensuring that it works

#5 make sure img error handling doesnt cause exceptions

#6 I still cannot access and play the levels i created.


