Creata a sokoban game clone using Python with the following specifications:
The player sprite must be able to move in all directions.
Blocks can only be pushed and not pulled.
Only one block can be pushed at a time.


Id like to expand the game dimension and add more boxes

