import pygame
import sys
import time

# Initialize Pygame
pygame.init()
pygame.font.init()

# --- Constants ---
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
LIGHT_BLUE = (173, 216, 230)
GRAY = (200, 200, 200)
BUTTON_COLOR = (100, 100, 200)
BUTTON_HOVER_COLOR = (150, 150, 250)
TEXT_INPUT_COLOR = (230, 230, 230)
TEXT_INPUT_ACTIVE_COLOR = WHITE

GAME_DURATION_SECONDS = 15
COUNTDOWN_SECONDS = 3

# Player configuration (can be expanded)
PLAYER_KEYS = [pygame.K_a, pygame.K_l, pygame.K_p, pygame.K_SEMICOLON]
PLAYER_COLORS = [RED, GREEN, BLUE, (255, 165, 0)]  # Orange for P4


# --- Game Class ---
class TapFrenzyGame:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Tap Frenzy!")
        self.clock = pygame.time.Clock()

        self.font_large = pygame.font.SysFont("Arial", 72)
        self.font_medium = pygame.font.SysFont("Arial", 48)
        self.font_small = pygame.font.SysFont("Arial", 32)
        self.font_tiny = pygame.font.SysFont("Arial", 24)

        self.game_state = "setup"  # setup, countdown, playing, results

        self.num_players = 2  # Default, can be changed in setup
        self.max_players = len(PLAYER_KEYS)
        self.player_names = ["Player 1", "Player 2", "Player 3", "Player 4"]
        self.player_scores = [0] * self.max_players
        self.player_keys_map = {}  # Will map player index to their key name for display

        self.active_text_input_idx = None  # For player name input

        self.countdown_timer = COUNTDOWN_SECONDS
        self.game_timer = GAME_DURATION_SECONDS
        self.start_ticks = 0  # For precise timing

        self.buttons = {}
        self.text_input_rects = []
        self.setup_ui_elements()

    def setup_ui_elements(self):
        """Initializes UI elements for the current game state."""
        self.buttons = {}
        self.text_input_rects = []
        self.active_text_input_idx = None

        if self.game_state == "setup":
            self.buttons["start_game"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 100, 200, 50),
                                          "text": "Start Game"}
            self.buttons["add_player"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 - 150, 80, 100, 40), "text": "+Player"}
            self.buttons["remove_player"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 + 50, 80, 100, 40),
                                             "text": "-Player"}

            for i in range(self.max_players):  # Create rects for all potential players
                self.text_input_rects.append(pygame.Rect(SCREEN_WIDTH // 2 - 150, 150 + i * 70, 300, 40))

            # Populate player_keys_map for display
            self.player_keys_map = {}
            for i in range(self.max_players):
                try:
                    key_name = pygame.key.name(PLAYER_KEYS[i]).upper()
                    self.player_keys_map[i] = key_name
                except IndexError:  # Should not happen if PLAYER_KEYS is populated
                    self.player_keys_map[i] = "N/A"


        elif self.game_state == "results":
            self.buttons["play_again"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 - 220, SCREEN_HEIGHT - 100, 200, 50),
                                          "text": "Play Again"}
            self.buttons["new_game"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 + 20, SCREEN_HEIGHT - 100, 200, 50),
                                        "text": "New Game (Setup)"}
            self.buttons["exit_game"] = {"rect": pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT - 160, 200, 50),
                                         "text": "Exit"}

    def reset_game_vars(self, reset_players=False):
        self.player_scores = [0] * self.max_players
        self.countdown_timer = COUNTDOWN_SECONDS
        self.game_timer = GAME_DURATION_SECONDS
        self.start_ticks = 0
        if reset_players:
            self.num_players = 2
            self.player_names = ["Player 1", "Player 2", "Player 3", "Player 4"]  # Reset names

    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False  # Signal to quit game

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    # Button clicks
                    for action, data in self.buttons.items():
                        if data["rect"].collidepoint(event.pos):
                            self.handle_button_action(action)
                            break  # Avoid multiple button clicks in one go

                    # Text input activation in setup
                    if self.game_state == "setup":
                        self.active_text_input_idx = None
                        for i in range(self.num_players):
                            if self.text_input_rects[i].collidepoint(event.pos):
                                self.active_text_input_idx = i
                                break

            if event.type == pygame.KEYDOWN:
                if self.game_state == "setup" and self.active_text_input_idx is not None:
                    idx = self.active_text_input_idx
                    if event.key == pygame.K_BACKSPACE:
                        self.player_names[idx] = self.player_names[idx][:-1]
                    elif event.key == pygame.K_RETURN or event.key == pygame.K_KP_ENTER:
                        self.active_text_input_idx = None  # Deactivate on enter
                    elif len(self.player_names[idx]) < 15:  # Limit name length
                        self.player_names[idx] += event.unicode

                elif self.game_state == "playing" and self.game_timer > 0:
                    for i in range(self.num_players):
                        if event.key == PLAYER_KEYS[i]:
                            self.player_scores[i] += 1
        return True  # Continue running

    def handle_button_action(self, action):
        if action == "start_game" and self.game_state == "setup":
            # Validate player names (e.g., not empty)
            valid_setup = True
            for i in range(self.num_players):
                if not self.player_names[i].strip():
                    print(f"Error: Player {i + 1}'s name cannot be empty.")  # TODO: Show on screen
                    valid_setup = False
                    break
            if valid_setup:
                self.game_state = "countdown"
                self.start_ticks = pygame.time.get_ticks()  # For countdown
        elif action == "add_player" and self.game_state == "setup":
            if self.num_players < self.max_players:
                self.num_players += 1
        elif action == "remove_player" and self.game_state == "setup":
            if self.num_players > 1:  # Minimum 1 player (or 2 for competitive)
                self.num_players -= 1
                if self.active_text_input_idx is not None and self.active_text_input_idx >= self.num_players:
                    self.active_text_input_idx = None  # Deactivate if it was for a removed player

        elif action == "play_again" and self.game_state == "results":
            self.reset_game_vars(reset_players=False)  # Keep current players and names
            self.game_state = "countdown"
            self.start_ticks = pygame.time.get_ticks()
        elif action == "new_game" and self.game_state == "results":
            self.reset_game_vars(reset_players=True)
            self.game_state = "setup"
            self.setup_ui_elements()
        elif action == "exit_game" and self.game_state == "results":
            pygame.quit()
            sys.exit()

    def update(self):
        current_ticks = pygame.time.get_ticks()
        elapsed_millis = current_ticks - self.start_ticks

        if self.game_state == "countdown":
            if elapsed_millis >= 1000:  # Every second
                self.countdown_timer -= 1
                self.start_ticks = current_ticks  # Reset for next second
                if self.countdown_timer < 0:  # Countdown finished
                    self.game_state = "playing"
                    self.game_timer = GAME_DURATION_SECONDS  # Ensure it's reset
                    self.start_ticks = current_ticks  # Start game timer

        elif self.game_state == "playing":
            if elapsed_millis >= 1000:
                self.game_timer -= 1
                self.start_ticks = current_ticks
                if self.game_timer <= 0:
                    self.game_timer = 0  # Ensure it doesn't go negative on display
                    self.game_state = "results"
                    self.setup_ui_elements()  # Setup buttons for results screen

    def draw_text(self, text, font, color, x, y, center=False):
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        if center:
            text_rect.center = (x, y)
        else:
            text_rect.topleft = (x, y)
        self.screen.blit(text_surface, text_rect)

    def draw_buttons_and_inputs(self):
        # Draw buttons
        mouse_pos = pygame.mouse.get_pos()
        for data in self.buttons.values():
            color = BUTTON_HOVER_COLOR if data["rect"].collidepoint(mouse_pos) else BUTTON_COLOR
            pygame.draw.rect(self.screen, color, data["rect"], border_radius=5)
            self.draw_text(data["text"], self.font_small, BLACK, data["rect"].centerx, data["rect"].centery,
                           center=True)

        # Draw text inputs for setup
        if self.game_state == "setup":
            for i in range(self.num_players):
                rect = self.text_input_rects[i]
                color = TEXT_INPUT_ACTIVE_COLOR if self.active_text_input_idx == i else TEXT_INPUT_COLOR
                pygame.draw.rect(self.screen, color, rect, border_radius=3)
                pygame.draw.rect(self.screen, BLACK, rect, 2, border_radius=3)  # Border

                # Player label and assigned key
                key_name = self.player_keys_map.get(i, "N/A")
                label_text = f"P{i + 1} Name (Key: {key_name}):"
                self.draw_text(label_text, self.font_tiny, BLACK, rect.x, rect.y - 22)

                # Player name text
                self.draw_text(self.player_names[i], self.font_small, BLACK, rect.x + 10,
                               rect.centery - self.font_small.get_height() // 2 + 2)

    def draw(self):
        self.screen.fill(LIGHT_BLUE)

        if self.game_state == "setup":
            self.draw_text("Game Setup", self.font_medium, BLACK, SCREEN_WIDTH // 2, 40, center=True)
            self.draw_text(f"Number of Players: {self.num_players}", self.font_small, BLACK, SCREEN_WIDTH // 2, 95,
                           center=True)
            self.draw_text("Note: This is a local multi-player game.", self.font_tiny, BLACK, SCREEN_WIDTH // 2,
                           SCREEN_HEIGHT - 180, center=True)
            self.draw_text("Fairness is ensured by synchronized local start/timing.", self.font_tiny, BLACK,
                           SCREEN_WIDTH // 2, SCREEN_HEIGHT - 155, center=True)


        elif self.game_state == "countdown":
            if self.countdown_timer > 0:
                countdown_text = str(self.countdown_timer)
            else:  # When timer hits 0, it's about to switch to "GO"
                countdown_text = "GO!"
            self.draw_text(countdown_text, self.font_large, BLACK, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2, center=True)

        elif self.game_state == "playing":
            # Timer display
            self.draw_text(f"Time: {self.game_timer}", self.font_medium, BLACK, SCREEN_WIDTH // 2, 50, center=True)

            # Player scores and keys
            start_y = 120
            for i in range(self.num_players):
                key_name = self.player_keys_map.get(i, "N/A")
                player_info = f"{self.player_names[i]} (Key: {key_name}): {self.player_scores[i]}"
                self.draw_text(player_info, self.font_small, PLAYER_COLORS[i], SCREEN_WIDTH // 2, start_y + i * 60,
                               center=True)

        elif self.game_state == "results":
            self.draw_text("Time's Up!", self.font_large, RED, SCREEN_WIDTH // 2, 100, center=True)

            winner_score = -1
            winners = []
            if any(s > 0 for s in self.player_scores[:self.num_players]):  # Check if anyone scored
                winner_score = max(self.player_scores[:self.num_players])
                for i in range(self.num_players):
                    if self.player_scores[i] == winner_score:
                        winners.append(self.player_names[i])

            if winners:
                if len(winners) > 1:
                    self.draw_text(f"It's a Tie! Winners: {', '.join(winners)}", self.font_medium, BLACK,
                                   SCREEN_WIDTH // 2, 200, center=True)
                else:
                    self.draw_text(f"Winner: {winners[0]}!", self.font_medium, GREEN, SCREEN_WIDTH // 2, 200,
                                   center=True)
                self.draw_text(f"Score: {winner_score} taps", self.font_medium, BLACK, SCREEN_WIDTH // 2, 250,
                               center=True)
            else:
                self.draw_text("No taps recorded!", self.font_medium, BLACK, SCREEN_WIDTH // 2, 200, center=True)

            # Display all scores
            y_offset = 320
            self.draw_text("Final Scores:", self.font_small, BLACK, SCREEN_WIDTH // 2, y_offset - 30, center=True)
            for i in range(self.num_players):
                score_text = f"{self.player_names[i]}: {self.player_scores[i]}"
                self.draw_text(score_text, self.font_small, PLAYER_COLORS[i], SCREEN_WIDTH // 2, y_offset + i * 40,
                               center=True)

        # Draw UI elements common to multiple states (buttons, inputs)
        self.draw_buttons_and_inputs()

        pygame.display.flip()

    def run(self):
        running = True
        while running:
            if not self.handle_input():  # handle_input returns False if QUIT event
                running = False
                break

            self.update()
            self.draw()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()


# --- Main Execution ---
if __name__ == "__main__":
    game = TapFrenzyGame()
    game.run()